<?php
/* Copyright (C) 2011	Regis Houssin	<regis.houssin@inodbox.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 * or see https://www.gnu.org/
 */

/**
 *	    \file       htdocs/core/lib/informationsrelease.lib.php
 *		\brief      Functions for module informationsrelease
 */

/**
 * Prepare array with list of tabs
 *
 * @param   Object	$object		Object related to tabs
 * @return  array				Array of tabs to show
 */
function informationsrelease_prepare_head($object)
{
	global $db, $langs, $conf;

	$h = 0;
	$head = array();

	$head[$h][0] = DOL_URL_ROOT.'/informationsrelease/card.php?id='.$object->id;
	$head[$h][1] = $langs->trans("InformationsRelease");
	$head[$h][2] = 'card';
	$h++;

	// Show more tabs from modules
	// Entries must be declared in modules descriptor with line
    // $this->tabs = array('entity:+tabname:Title:@mymodule:/mymodule/mypage.php?id=__ID__');   to add new tab
    // $this->tabs = array('entity:-tabname);   												to remove a tab
	complete_head_from_modules($conf, $langs, $object, $head, $h, 'informationsrelease');

	require_once DOL_DOCUMENT_ROOT.'/core/lib/files.lib.php';
    require_once DOL_DOCUMENT_ROOT.'/core/class/link.class.php';
	$upload_dir = $conf->informationsrelease->dir_output."/".dol_sanitizeFileName($object->ref);
	$nbFiles = count(dol_dir_list($upload_dir, 'files', 0, '', '(\.meta|_preview.*\.png)$'));
    $nbLinks = Link::count($db, $object->element, $object->id);
	$head[$h][0] = DOL_URL_ROOT.'/informationsrelease/document.php?id='.$object->id;
	$head[$h][1] = $langs->trans('Documents');
	if (($nbFiles + $nbLinks) > 0) $head[$h][1] .= '<span class="badge marginleftonlyshort">'.($nbFiles + $nbLinks).'</span>';
	$head[$h][2] = 'documents';
	$h++;

	if (empty($conf->global->MAIN_DISABLE_NOTES_TAB))
	{
	    $nbNote = 0;
	    if (!empty($object->note_private)) $nbNote++;
	    if (!empty($object->note_public)) $nbNote++;
	    $head[$h][0] = DOL_URL_ROOT.'/informationsrelease/note.php?id='.$object->id;
	    $head[$h][1] = $langs->trans('Notes');
	    if ($nbNote > 0) $head[$h][1] .= '<span class="badge marginleftonlyshort">'.$nbNote.'</span>';
	    $head[$h][2] = 'note';
	    $h++;
	}

	$head[$h][0] = DOL_URL_ROOT.'/informationsrelease/info.php?id='.$object->id;
	$head[$h][1] = $langs->trans("Info");
	$head[$h][2] = 'info';
	$h++;

	complete_head_from_modules($conf, $langs, $object, $head, $h, 'informationsrelease', 'remove');

	return $head;
}

/**
 * Returns an array with the tabs for the "Expense report payment" section
 * It loads tabs from modules looking for the entity payment
 *
 * @param	Paiement	$object		Current payment object
 * @return	array					Tabs for the payment section
 */
function payment_informationsrelease_prepare_head(PaymentInformationsRelease $object)
{

	global $langs, $conf;

	$h = 0;
	$head = array();

	$head[$h][0] = DOL_URL_ROOT.'/informationsrelease/payment/card.php?id='.$object->id;
	$head[$h][1] = $langs->trans("InformationsRelease");
	$head[$h][2] = 'payment';
	$h++;

    // Show more tabs from modules
    // Entries must be declared in modules descriptor with line
    // $this->tabs = array('entity:+tabname:Title:@mymodule:/mymodule/mypage.php?id=__ID__');   to add new tab
    // $this->tabs = array('entity:-tabname);   												to remove a tab
    complete_head_from_modules($conf, $langs, $object, $head, $h, 'payment_informationsrelease');

	$head[$h][0] = DOL_URL_ROOT.'/informationsrelease/payment/info.php?id='.$object->id;
	$head[$h][1] = $langs->trans("Info");
	$head[$h][2] = 'info';
	$h++;

	complete_head_from_modules($conf, $langs, $object, $head, $h, 'payment_informationsrelease', 'remove');

	return $head;
}

/**
 *  Return array head with list of tabs to view object informations.
 *
 *  @return	array   	        head array with tabs
 */
function informationsrelease_admin_prepare_head()
{
	global $langs, $conf, $user;

	$h = 0;
	$head = array();

	$h = 0;

	$head[$h][0] = DOL_URL_ROOT."/admin/informationsrelease.php";
	$head[$h][1] = $langs->trans("InformationsReleases");
	$head[$h][2] = 'informationsrelease';
	$h++;

	if (!empty($conf->global->MAIN_USE_EXPENSE_IK))
	{
		$head[$h][0] = DOL_URL_ROOT."/admin/informationsrelease_ik.php";
		$head[$h][1] = $langs->trans("InformationsReleasesIk");
		$head[$h][2] = 'expenseik';
		$h++;
	}

	if (!empty($conf->global->MAIN_USE_EXPENSE_RULE))
	{
		$head[$h][0] = DOL_URL_ROOT."/admin/informationsrelease_rules.php";
		$head[$h][1] = $langs->trans("InformationsReleasesRules");
		$head[$h][2] = 'expenserules';
		$h++;
	}

	// Show more tabs from modules
	// Entries must be declared in modules descriptor with line
	// $this->tabs = array('entity:+tabname:Title:@mymodule:/mymodule/mypage.php?id=__ID__');   to add new tab
	// $this->tabs = array('entity:-tabname:Title:@mymodule:/mymodule/mypage.php?id=__ID__');   to remove a tab
	complete_head_from_modules($conf, $langs, null, $head, $h, 'informationsrelease_admin');

	$head[$h][0] = DOL_URL_ROOT.'/admin/informationsrelease_extrafields.php';
	$head[$h][1] = $langs->trans("ExtraFields");
    $head[$h][2] = 'attributes';
    $h++;

    /*
	$head[$h][0] = DOL_URL_ROOT.'/fichinter/admin/fichinterdet_extrafields.php';
	$head[$h][1] = $langs->trans("ExtraFieldsLines");
    $head[$h][2] = 'attributesdet';
    $h++;
	*/

	complete_head_from_modules($conf, $langs, null, $head, $h, 'informationsrelease_admin', 'remove');

    return $head;
}
